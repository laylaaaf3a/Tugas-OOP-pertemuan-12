from kucing import *

lele = kucing('lele', 'putih', 2)

lele.data_kucing()